

<?php $__env->startSection('title', 'CELAQUE SOCIAL'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>MIS POSTS</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row my-3">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5>Nuevo Post</h5>
                </div>  
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <p class="lead">Que estas pensando <?php echo e(auth()->user()->name); ?>?</p>
                        </div>
                    </div>
                    <form action="<?php echo e(route('posts.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>   
                        <div class="form-group">
                            <textarea name="post" class="form-control" placeholder="¿Qué estas pensando?" required></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success"> Publicar </button>
                            <input type="file" name="file" id="" accept="image/*">
                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-12">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card">
                    <div class="card-body">
                        <p class="lead" align="center"><strong><?php echo e($post->post); ?></strong></p>
                        <p align="center"><img src="<?php echo e($post->image); ?>" alt="" class="img-fluid" ></p>
                        <hr>
                        <form action="<?php echo e(route('comments.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="text" name="comment" placeholder="Escribe un comentario" class="form-control" autocomplete="off" required>

                                <hr>
                                <?php $__empty_2 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <div class="card">
                                    <div class="card-body py-1">
                                        <p class="card-text lead my-0"><?php echo e($comment->comentario); ?></p>

                                        <div class="row">
                                            <div class="col-6">
                                            <small><?php echo e($comment->user->name); ?></small>        
                                            </div>
                                            <div class="col-6">
                                            <small><?php echo e($comment->created_at->diffForHumans()); ?></small> 
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                <input type="hidden" name="destino" value="<?php echo e($post->user->email); ?>">
                                <input type="hidden" name="propietario" value="<?php echo e($post->user->name); ?>">
                                <input type="hidden" name="postp" value="<?php echo e($post->post); ?>">
                                <input type="hidden" name="idprop" value="<?php echo e($post->user->id); ?>">
                            </div>
                        </form>
                    </div>
                    <div class="card-footer text-muted">
                        <div class="row">
                            <div class="col-4"><small><?php echo e($post->created_at->diffForHumans()); ?></small></div>
                            <div class="col-4"><small "fa-solid fa-comment-captions">
                                Comentarios <?php echo e($post->comments->count()); ?></small></div>
                            <div class="col-4"><small>Like: 45</small></div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\ING_SOFT\celaqueproyecto\resources\views/posts/index.blade.php ENDPATH**/ ?>