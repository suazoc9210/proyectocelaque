

<?php $__env->startSection('title', 'CELAQUE SOCIAL'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 my-3">
            <div class="card">
                <div class="card-body">
                    <strong class="d-block">Este es un post de <?php echo e($post->user->name); ?></strong>
                        <p class="lead" align="center"><strong><?php echo e($post->post); ?></strong></p>
                        <p align="center"><img src="<?php echo e($post->image); ?>" alt="" class="img-fluid" ></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <form action="<?php echo e(route('storex')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-gruop">
                    <input type="text" name="comment" placeholder="Escribe un comentario" class="form-control" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                    <input type="hidden" name="destino" value="<?php echo e($post->user->email); ?>">
                    <input type="hidden" name="propietario" value="<?php echo e($post->user->name); ?>">
                    <input type="hidden" name="postp" value="<?php echo e($post->post); ?>">
                    <input type="hidden" name="idprop" value="<?php echo e($post->user->id); ?>">
                    
                </div>                
                <div class="form my-3">
                    <button type="submit" class="btn btn-outline-success btn-sm">Comentar</button>
                </div>
                    <div>
                    <div class="row">
                        <div class="col-12">
                        <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="card">
                            <div class="card-body">
                                <p class='card-text'><?php echo e($comment->comentario); ?></p>
                                <p><strong><?php echo e($comment->user->name); ?></strong></p>
                            </div>
                            <div class="card-footer">
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                        </div>
                    </div>
                    </div>                
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\ING_SOFT\celaqueproyecto\resources\views/posts/show.blade.php ENDPATH**/ ?>