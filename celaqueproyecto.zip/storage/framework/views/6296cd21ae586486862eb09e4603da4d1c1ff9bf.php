<h1>CELAQUE social</h1>
<h2>Hola <?php echo e($post->user->name); ?>! Tu post acaba de recibir un comentario nuevo</h2>
<h3></h3>
<?php /**PATH C:\Users\Dell\Desktop\ING_SOFT\celaqueproyecto\resources\views/comments/commentpost.blade.php ENDPATH**/ ?>