<?php echo e($slot); ?>

<?php /**PATH C:\Users\Dell\Desktop\ING_SOFT\celaqueproyecto\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>