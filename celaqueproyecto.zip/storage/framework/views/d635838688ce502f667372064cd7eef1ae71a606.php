<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro</title>
</head>
<body style="background-image: url('celaque.jpeg');
            background-repeat:no-repeat;
            background-attachment: fixed;
            background-size: cover;">
  
</body>
</html>

<?php echo $__env->make('adminlte::auth.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\ING_SOFT\celaqueproyecto\resources\views/auth/register.blade.php ENDPATH**/ ?>