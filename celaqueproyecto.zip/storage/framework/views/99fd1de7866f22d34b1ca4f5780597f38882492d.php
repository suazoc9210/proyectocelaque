<div class="div">
	<h1>Tu publicacion ha recibido un nuevo comentario</h1>
</div>
<?php /**PATH C:\Users\Dell\Desktop\ING_SOFT\celaqueproyecto\resources\views/posts/mails/commentpost.blade.php ENDPATH**/ ?>