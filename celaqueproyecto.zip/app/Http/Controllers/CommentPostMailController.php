<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comment;
use App\Models\Post;
use App\Models\User;
use App\Mail\CommentPostMail;
use Illuminate\Support\Facades\Mail;

class CommentPostMailController extends Controller
{
    $detalle=[
        'titulo' => 'Nueva Notificacion de Correo'
        'body' => 'Tu publicacion ha recibido un nuevo comentario'
        'body' => 
    ]
}
